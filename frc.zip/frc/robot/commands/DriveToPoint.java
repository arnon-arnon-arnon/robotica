// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.commands;

import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.wpilibj2.command.PIDCommand;
import frc.robot.Constants;
import frc.robot.subsystems.DriveAndTurn_Subsystem;

// NOTE:  Consider using this command inline, rather than writing a subclass.  For more
// information, see:
// https://docs.wpilib.org/en/stable/docs/software/commandbased/convenience-features.html
public class DriveToPoint extends PIDCommand {
  private DriveAndTurn_Subsystem drive=new DriveAndTurn_Subsystem();
  private double Point;

  public DriveToPoint(DriveAndTurn_Subsystem drive, double target) {
    super(
        // The controller that the command will use
        new PIDController(Constants.DriveConstants.kDriveP, Constants.DriveConstants.kDriveI, Constants.DriveConstants.kDriveD),
      
        drive::getBothEncoders,
        // Set reference to target,,, LOOK IN ROTATETOANGLE
        target,
        // Pipe output to turn robot,,, LOOK IN ROTATETOANGLE
        output -> drive.arcadeDrive(output, 0),
        // Require the drive,,, LOOK IN ROTATETOANGLE
        drive);

        this.drive = drive;
        Point = target;

        getController().enableContinuousInput(-3, 3);

        getController()
            .setTolerance(Constants.DriveConstants.kDriveToToleranceMeters, Constants.DriveConstants.kDriveRateToleranceMetersPerS);
        getController().reset();
  }

  
  @Override
  public void initialize(){
    drive.resetEncoders();
  }




  // Returns true when the command should end.,,, ONCE CODE ENDS, DISPLAYS STATISTICS OF THE DRIVING
  @Override
  public boolean isFinished() {
    System.out.println("length driven is "+ drive.getBothEncoders());
    System.out.println("the controller is at set point:"+ getController().atSetpoint());
    if(Math.abs(drive.getBothEncoders()) > Math.abs(Point) * 0.95 || getController().atSetpoint() ){
      return true;
    }
    return false;
  }
}

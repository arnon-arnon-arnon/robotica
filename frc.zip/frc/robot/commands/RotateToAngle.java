// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.commands;

import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.wpilibj2.command.PIDCommand;
import frc.robot.Constants;
import frc.robot.subsystems.DriveAndTurn_Subsystem;

// NOTE:  Consider using this command inline, rather than writing a subclass.  For more
// information, see:
// https://docs.wpilib.org/en/stable/docs/software/commandbased/convenience-features.html
public class RotateToAngle extends PIDCommand {
  private DriveAndTurn_Subsystem drive;

  /** Creates a new RotateToAngle. */
  public RotateToAngle(double targetAngleDegrees, DriveAndTurn_Subsystem drive) {
    super(
        // The controller that the command will use
        new PIDController(Constants.DriveConstants.kTurnP, Constants.DriveConstants.kTurnI, Constants.DriveConstants.kTurnD),
        
        drive::getHeading,
        // Set reference to target,,, INSERTS DRIVE FUNCTION INTO GETHEADING FUNCTION- IN PRACTICE JUST GETS YOUR DEGREE-POSITION
        targetAngleDegrees,
        // Pipe output to turn robot,,, SHMUEL WILL EXPLAIN
        output -> drive.arcadeDrive(0, output),
        // Require the drive,,, THIS IS JUST A LINE SO TWO COMMANDS DONT USE THE SAME MOTOR
        drive);

    this.drive = drive;
    // Set the controller to be continuous (because it is an angle controller)
    getController().enableContinuousInput(-180, 180);
    // Set the controller tolerance - the delta tolerance ensures the robot is stationary at the
    // setpoint before it is considered as having reached the reference
    getController()
        .setTolerance(Constants.DriveConstants.kTurnToleranceDeg, Constants.DriveConstants.kTurnRateToleranceDegPerS);
  }


// RESETS GYRO WHEN STARTS TO RUN, MAKES SURE WE DONT USE OLD INPUTS
@Override
public void initialize(){
  drive.resetGyro();
}

  
  // Returns true when the command should end.
  @Override
  public boolean isFinished() {
    // End when the controller is at the reference.,,, 
    return getController().atSetpoint();
  }
}
